/* This is where you'll complete the Milestone. Open your README.md file and click 'Open Preview' for detailed instuctions! */

function calculateCarpet() {
  // 👇 Write your code here 👇
  
  console.log("click");
  //TODO 1- Get the demensions of the room
  // TODO Get the width of Room 1 AND store it in a variable -
  getRoomWidth (1);
  // TODO Get the length of Room 1 AND store it in a variable -
  getRoomLength (1);
  // TODO Get the width of Room 2 AND store it in a variable -
  getRoomWidth (2);
  // TODO Get the Length of Room 2 AND store it in a variable -
  getRoomLength (2);
  // TODO 2 - Do the calculations
  // TODO Calculate the area of Room 1 (its length * width)\
  let room1Area = getRoomWidth (1) * getRoomLength (1);
  // TODO Calculate the area of Room 2 (its length * width)
  let room2Area = getRoomWidth (2) * getRoomLength (2);
  // TODO Add them together (areal + area2)
  let totArea = room1Area + room2Area;
  // TODO Multiply the total by 1.1
  let result = totArea * 1.1;
  // TODO Output the result to the screen - HINT: Use an HTML element, such as a <p>, to

  
  // TODO 3 - Show the result, profit
  // Use showResult( result)
  showResult(result);
}
calculateCarpetTest();

/* LEVEL UP! (optional) 
	1. Function explanations: 


	2. Custom styles added: 


*/