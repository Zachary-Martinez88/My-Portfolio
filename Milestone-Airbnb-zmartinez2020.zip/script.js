function filterByCity(targetCity, listingCityArray) {
  // declare variable 
  let matchingIndices = [];

  // using a for loop 
  for (let i = 0; i < listingCityArray.length; i++) {
    // using the if statement
    if (listingCityArray[i].toLowerCase() === targetCity.toLowerCase()){
      matchingIndices.push(i);
    }
  }
  return matchingIndices;
}

// filtering by price 

function filterByPrice(minPrice, maxPrice, listingPriceArray) {
  // declare variable
  let matchingIndices = [];
  // for loop
  for (let i = 0; i < listingPriceArray.length; i++) {

    if (listingPriceArray[i] >= minPrice && listingPriceArray[i] <= maxPrice) {
      matchingIndices.push(i);
    }
  }
  return matchingIndices;
}

  // Note: Comment out the following line when you start working on this function!
  // return [...listingPriceArray.keys()]


// // LevelUp!
function filterByTypes(targetTypes, listingTypeArray) {
//   // Note: Comment out the following line when you attempt the LevelUp!


return [...listingTypeArray.keys()]
}