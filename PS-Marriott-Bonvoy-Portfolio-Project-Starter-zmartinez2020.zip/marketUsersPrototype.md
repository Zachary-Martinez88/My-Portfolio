# Market, Users, Prototype

## Understand Your Market
*Provide links to the 3 websites you explored*
<ul>
<li>https://www.bluepillow.com/</li>
  <li>https://www.wimdu.com/ </li>
  <li>https://www.homestay.com/</li>
  <li>https://www.vacasa.com/</li>
  <li>https://www.vrbo.com/</li>
  <li>https://www.airbnb.com/</li>
</ul>

*Briefly explain why these websites are a relevant comparison* 
The relevance of these websites to this project is that all six of them are direct competitors to our client, 


<ol>
*List at least 10 product features*
  <li>user can click on ims of top destinations and find listings in said destination</li>
<li>user can filter by reviews of the property</li> 
<li>The user can filter based on distance from the location</li>
<li>user can filter by facilities of the property </li>
<li>user can change the type of currency</li>
  <li>users can see recently booked places in a carousel on the front page </li>
    <li>user can hit a button under an inspiration category like calling all students and they would get recommended listings </li>
      <li>users can go to a deals page so they can find coupons to save money on their reservation </li>
  <li>users can hit a toggle to see the price before taxes </li>
    <li>Users can view the location of the listing on a map when hovering over the listing</li>
</ol>
## Understand Your Users
*Write a short paragraph (50-100 words) describing the themes that emerged from the user research*

The user research suggests that the website is effective when clients know where they want to go. On that note, the website seems to be missing critical features for people who don’t know where they want to go on vacation, like ways to discover the destinations displayed on the site, for example, hover page on the home screen, overviewing the popular destinations and a way to search by attractions near the destination. I believe the users would benefit from a more simplified format that adds information about each destination for the user on top of the website's current function.

## Define and Prototype
*Paste a link to your prototype here* 
> **🗒️ NOTE:** Make sure you share your prototype file so that "anyone with the link" can view it. If we're unable to access your file, we'll be unable to give you credit. 

*Don't forget to include a comment if you attempted any of the LevelUps, so that your grader knows to review your work and award the extra credit!* 

https://docs.google.com/presentation/d/1U5XkBIkie7kikBna1sFufLa20oa1LRo73Be_jujWuvI/edit?usp=sharing