const imageSources = [
  "assets/trail.jpg",
  "assets/lakesunset.jpg",
  "assets/cabin.jpg",
  "assets/doe.jpg",
  "assets/starrynight.jpg",
];

function addThumbnail(imageSource) {
  // 1.1 Create the element
  const thumbnailImg = document.createElement("img");
  // 1.2 Customize the element
  thumbnailImg.src = imageSource;

thumbnailImg.classList.add("thumbnail")
  // 1.3 Append the element
  const thumnbnailContainer = document.getElementById("thumbnail-container");    

  thumnbnailContainer.appendChild(thumbnailImg);
  // 1.4 Add the onclick
  thumbnailImg.onclick = function(){
    const fullsizeImage = document.getElementById("fullsize-image");
    fullsizeImage.src = imageSource;
  } ;
}

function addAllThumbnails() {
  // 2.1 Loop through imageSources
  for (let i = 0; i < imageSources.length; i++){  
  
  // 2.2 Call addThumbnail each iteration 
    addThumbnail(imageSources[i]);
  }
}

// 2.3 Call addAllThumbnails
addAllThumbnails();

// LevelUp Display the first image on page load
const fullsizeImage = document.getElementById("fullsize-image");
fullsizeImage.src = imageSources[0];

